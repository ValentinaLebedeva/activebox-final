/* additing action for mobile menu btn */

const navMobile = document.querySelector(".nav-mobile");
const navMobileInner = document.querySelector(".nav-mobile__inner");

navMobile.addEventListener("click", openMenu);

function openMenu() {
    navMobileInner.classList.toggle("nav-mobile__inner--active");
    navMobileInner.classList.toggle("nav-mobile__inner--close");
}
